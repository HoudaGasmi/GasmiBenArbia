export class Login {
    constructor (
        public nom?: string,
        public mdp?: string        
        ){}
}
