import { PersoPipePipe } from './perso-pipe.pipe';

describe('PersoPipePipe', () => {
  it('create an instance', () => {
    const pipe = new PersoPipePipe();
    expect(pipe).toBeTruthy();
  });
});
