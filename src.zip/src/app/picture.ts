export class Picture {
    constructor (
        public image1?: string,
        public image2?: string, 
        public image3?: string
       
        ){}
}
