// import { Component, Input, OnInit } from '@angular/core';
// import { Hotel } from '../hotel';
// import { PersoPipePipe } from '../perso-pipe.pipe';

// @Component({
//   selector: 'app-list-hotel',
//   templateUrl: './list-hotel.component.html',
//   styleUrls: ['./list-hotel.component.css']
// })
// export class ListHotelComponent implements OnInit {

//   @Input() hotel: Hotel=new Hotel();
//   display:boolean = false;
//   onAfficher(){
//   this.display= !this.display;
//   }
//   constructor() { }

//   ngOnInit(): void {
//   }

// }
