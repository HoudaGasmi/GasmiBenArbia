import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-btt',
  templateUrl: './btt.component.html',
  styleUrls: ['./btt.component.css']
})
export class BTTComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
